import UIKit

for i in 1...10{
    print(i)
}

var total_1 : Int = 0
var total_2 : Int = 0
var j : Int = 0

for x in 1...20{
    print(x)
    total_1 = total_1+x
}

while j < 20{
    j = j+1
    print(j)
    total_2 = total_2 + j
}

print(total_1, total_2)
